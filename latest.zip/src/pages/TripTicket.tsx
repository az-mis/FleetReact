import React, { useEffect, useState } from "react";
import { doc, getDoc } from "firebase/firestore";
import { useParams, Link } from "react-router-dom";
import { db } from "../firebase";
import { VehicleRequest } from "../types";
import { ArrowLeft, Printer, AlertTriangle } from "lucide-react";

type LoadState = "loading" | "not_found" | "not_approved" | "error" | "ready";

/** yyyy-mm-dd -> "July 24, 2026" */
function longDate(value?: string | null): string {
  if (!value) return "";
  const [y, m, d] = value.split("-").map(Number);
  if (!y || !m || !d) return value;
  return new Date(y, m - 1, d).toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });
}

/** Combines travelDate/travelDateEnd into the ticket's "Duration or Date of travel" line. */
function durationLabel(request: VehicleRequest): string {
  const start = longDate(request.travelDate);
  if (!request.travelDateEnd || request.travelDateEnd === request.travelDate) return start;
  return `${start} to ${longDate(request.travelDateEnd)}`;
}

export default function TripTicket() {
  const { id } = useParams<{ id: string }>();
  const [state, setState] = useState<LoadState>("loading");
  const [request, setRequest] = useState<VehicleRequest | null>(null);
  const [vehicleLabel, setVehicleLabel] = useState<string>("");

  useEffect(() => {
    if (!id) return;
    (async () => {
      try {
        const snap = await getDoc(doc(db, "vehicleRequests", id));
        if (!snap.exists()) {
          setState("not_found");
          return;
        }
        const data = { id: snap.id, ...(snap.data() as Omit<VehicleRequest, "id">) };
        if (data.status !== "approved") {
          setState("not_approved");
          return;
        }
        setRequest(data);
        // Brand/model isn't snapshotted on the request, so look it up from
        // the vehicle doc to prefix the plate number (e.g. "Toyota Vios").
        if (data.vehicleId) {
          try {
            const vSnap = await getDoc(doc(db, "vehicles", data.vehicleId));
            if (vSnap.exists()) {
              const v = vSnap.data() as { brand?: string; model?: string };
              setVehicleLabel([v.brand, v.model].filter(Boolean).join(" "));
            }
          } catch {
            // Non-fatal — the ticket still works with just the plate number.
          }
        }
        setState("ready");
      } catch {
        setState("error");
      }
    })();
  }, [id]);

  if (state === "loading") {
    return <CenteredMessage>Loading trip ticket…</CenteredMessage>;
  }
  if (state === "not_found") {
    return (
      <CenteredMessage icon={AlertTriangle}>
        We couldn't find that request.
        <BackLink />
      </CenteredMessage>
    );
  }
  if (state === "not_approved") {
    return (
      <CenteredMessage icon={AlertTriangle}>
        This request hasn't been approved yet, so there's no trip ticket to print.
        <BackLink />
      </CenteredMessage>
    );
  }
  if (state === "error" || !request) {
    return (
      <CenteredMessage icon={AlertTriangle}>
        Something went wrong loading this trip ticket. Please try again.
        <BackLink />
      </CenteredMessage>
    );
  }

  const driverName = request.confirmedDriverName || request.defaultDriverName || "";
  const plateLabel = vehicleLabel ? `${vehicleLabel}, ${request.vehiclePlateNumber}` : request.vehiclePlateNumber;

  return (
    <div style={{ background: "#e9ebee", minHeight: "100vh" }}>
      {/* Toolbar — hidden when printing */}
      <div
        className="no-print"
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "12px 20px",
          background: "#fff",
          borderBottom: "1px solid var(--border)",
          position: "sticky",
          top: 0,
          zIndex: 10,
        }}
      >
        <Link
          to={`/check-status?code=${request.id}`}
          style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "13px", color: "var(--text-muted)", textDecoration: "none" }}
        >
          <ArrowLeft size={15} /> Back to status
        </Link>
        <button
          onClick={() => window.print()}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "6px",
            padding: "9px 16px",
            borderRadius: "8px",
            border: "none",
            background: "var(--primary)",
            color: "#fff",
            fontWeight: 700,
            fontSize: "13.5px",
            cursor: "pointer",
          }}
        >
          <Printer size={15} /> Print / Save as PDF
        </button>
      </div>

      <style>{`
        @media print {
          .no-print { display: none !important; }
          body { background: #fff !important; }
        }
        @page { size: A4; margin: 15mm; }
      `}</style>

      {/* The ticket itself */}
      <div
        style={{
          maxWidth: "210mm",
          minHeight: "297mm",
          margin: "24px auto",
          background: "#fff",
          padding: "18mm 16mm",
          fontFamily: "'Segoe UI', Arial, Helvetica, sans-serif",
          fontSize: "15px",
          lineHeight: 1.6,
          color: "#1a1a1a",
          boxShadow: "0 4px 24px rgba(0,0,0,0.12)",
          boxSizing: "border-box",
        }}
      >
        <div style={{ textAlign: "center", fontSize: "13px", lineHeight: 1.6 }}>
          <div>Republic of the Philippines</div>
          <div style={{ fontWeight: 700 }}>DEPARTMENT OF AGRICULTURE</div>
          <div style={{ fontWeight: 700 }}>MIMAROPA REGION</div>
          <div>JP Rizal St., Brgy. Camilmil, Calapan City, Oriental Mindoro</div>
          <div>Satellite Office: ATI Building, Elliptical Rd., Brgy. Vasra, Diliman, Quezon City</div>
          <div>Tel. No: (02)8927-43-50/8332-72-74</div>
          <div>Email Add: mimaropa@mail.gov.ph/ored4b@yahoo.com</div>
        </div>

        <div style={{ textAlign: "right", fontSize: "14px", marginTop: "8px" }}>Appendix A</div>

        <h1 style={{ textAlign: "center", fontSize: "22px", letterSpacing: "0.5px", margin: "14px 0" }}>
          DRIVER'S TRIP TICKET
        </h1>

        <div style={{ textAlign: "right", fontSize: "15px", marginBottom: "16px" }}>
          <div>
            No. <U w={90}>{request.id}</U>
          </div>
          <div style={{ marginTop: "4px" }}>
            <U w={160}>
              {new Date(
                request.approvedAt?.toDate ? request.approvedAt.toDate() : Date.now()
              ).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}
            </U>
          </div>
        </div>

        <p style={{ fontSize: "15px", fontWeight: 700, marginBottom: "10px" }}>
          A. To be filled by the Administrative Official Authorizing Official Travel:
        </p>

        <div style={{ lineHeight: 1.3 }}>
          <TicketRow n={1} label="Name of Driver of the vehicle" value={driverName} />
          <TicketRow n={2} label="Government car to be used, Plate No." value={plateLabel} />
          <TicketRow n={3} label="Name of authorized passenger" value={request.passengers || ""} />
          <TicketRow n={4} label="Duration or Date of travel" value={durationLabel(request)} />
          <TicketRow n={5} label="Place or places to be visited" value={request.destination} />
          <div style={{ display: "flex", fontSize: "15px", marginBottom: "6px" }}>
            <div style={{ width: "28px", flexShrink: 0 }}>6</div>
            <div style={{ width: "290px", flexShrink: 0 }}>Purpose :</div>
            <div style={{ flex: 1, borderBottom: "1px solid #333", minHeight: "22px", whiteSpace: "pre-wrap" }}>
              {request.purpose}
            </div>
          </div>
          <TicketRow n={7} label="Previous date of Travel Trip Ticket" value={longDate(request.previousTripTicketDate)} />
        </div>

        <div style={{ textAlign: "center", marginTop: "36px", fontSize: "15px" }}>
          <div>Approved by:</div>
          <div style={{ marginTop: "30px", fontWeight: 700 }}>{request.approvedByName || ""}</div>
          <div style={{ borderTop: "1px solid #333", width: "270px", margin: "2px auto 0" }} />
        </div>

        <p style={{ fontSize: "12px", color: "#666", marginTop: "24px" }}>
          Requested by {request.requesterName}
          {request.requesterOffice ? `, ${request.requesterOffice}` : ""} — Reference code {request.id}
        </p>
      </div>
    </div>
  );
}

/** A single numbered "label ......... value" row, matching the paper form. */
function TicketRow({ n, label, value }: { n: number; label: string; value: string }) {
  return (
    <div style={{ display: "flex", fontSize: "15px", marginBottom: "8px" }}>
      <div style={{ width: "28px", flexShrink: 0 }}>{n}</div>
      <div style={{ width: "290px", flexShrink: 0 }}>{label}</div>
      <div style={{ flex: 1, borderBottom: "1px solid #333", paddingBottom: "3px" }}>{value}</div>
    </div>
  );
}

function U({ children, w }: { children: React.ReactNode; w: number }) {
  return (
    <span style={{ display: "inline-block", minWidth: `${w}px`, borderBottom: "1px solid #333" }}>{children}</span>
  );
}

function CenteredMessage({
  children,
  icon: Icon,
}: {
  children: React.ReactNode;
  icon?: any;
}) {
  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: "10px",
        textAlign: "center",
        padding: "24px",
        color: "var(--text-muted)",
        fontSize: "14px",
      }}
    >
      {Icon && <Icon size={28} />}
      <div>{children}</div>
    </div>
  );
}

function BackLink() {
  return (
    <Link
      to="/check-status"
      style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "13px", color: "var(--primary)", marginTop: "8px" }}
    >
      <ArrowLeft size={14} /> Back to status lookup
    </Link>
  );
}
